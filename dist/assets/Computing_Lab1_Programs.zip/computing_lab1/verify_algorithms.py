"""Meaningful regression checks. Run: python verify_algorithms.py"""
import contextlib
import importlib.util
import io
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

BASE = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location("lab_" + name[:2], BASE / name)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main():
    id3 = load("01_id3.py")
    weather = pd.read_csv(BASE / "data/weather.csv", dtype=str)
    features = [c for c in weather if c not in {"id", "play"}]
    root = id3.id3(weather, features)
    assert root.attribute == "outlook"
    assert all(id3.classify(root, row) == row["play"] for row in weather.to_dict("records"))
    assert id3.classify(root, {"outlook": "unseen"}) == "yes"
    assert id3.classify(root, {"outlook": "sunny", "humidity": "unknown"}) == "no"
    pure = id3.id3(weather[weather.play == "yes"], features)
    assert pure.attribute is None and id3.classify(pure, {}) == "yes"
    assert id3.classify(id3.id3(weather, []), {}) == "yes"
    xor = pd.DataFrame({"a": [0, 0, 1, 1], "b": [0, 1, 0, 1], "play": ["no", "yes", "yes", "no"]})
    tree = id3.id3(xor, ["a", "b"])
    assert all(id3.classify(tree, row) == row["play"] for row in xor.to_dict("records"))
    print("PASS: ID3 tree, pure/exhausted cases, unseen values and zero-gain XOR.")

    nb = load("02_naive_bayes.py")
    for name in ["iris", "wine"]:
        data = pd.read_csv(BASE / "data" / (name + ".csv"))
        train_x, test_x, train_y, _ = train_test_split(
            data.iloc[:, :-1], data.iloc[:, -1], test_size=0.2, random_state=42, stratify=data.iloc[:, -1]
        )
        imputer = SimpleImputer(strategy="median", keep_empty_features=True)
        train_x, test_x = imputer.fit_transform(train_x), imputer.transform(test_x)
        scratch = nb.GaussianNBFromScratch().fit(train_x, train_y)
        library = GaussianNB().fit(train_x, train_y)
        np.testing.assert_array_equal(scratch.predict(test_x), library.predict(test_x))
    constant = nb.GaussianNBFromScratch().fit(np.ones((6, 2)), [0, 0, 0, 1, 1, 1])
    assert np.isfinite(constant.joint_log_likelihood([[1, 1], [1e6, -1e6]])).all()
    print("PASS: Gaussian NB agrees with sklearn; constant/extreme features yield finite scores.")

    document = load("03_document_classifier.py")
    with contextlib.redirect_stdout(io.StringIO()):
        pipeline, train_text, test_text = document.main()
    normalize = lambda s: s.str.lower().str.replace(r"\s+", " ", regex=True)
    assert not set(normalize(train_text)) & set(normalize(test_text))
    assert pipeline.predict(["a previously unseen message"])[0] in {"ham", "spam"}
    print("PASS: Document train/test messages are disjoint; new-document prediction works.")

    heart = load("04_heart_bayesian_network.py")
    with contextlib.redirect_stdout(io.StringIO()):
        model, test_d, states, probabilities = heart.main()
    assert set(model.nodes()) == set(heart.FEATURES + ["target"])
    assert model.check_model() and len(model.get_cpds()) == len(model.nodes())
    for cpd in model.get_cpds():
        np.testing.assert_allclose(cpd.get_values().sum(axis=0), 1.0)
        assert np.isfinite(cpd.values).all()
    assert "target" not in test_d
    assert len(probabilities) == 61 and np.isfinite(probabilities).all()
    assert all(0 <= p <= 1 for p in probabilities)
    for column in test_d:
        assert set(test_d[column]).issubset(states[column])
    # Modifying held-out values must not change learned training cut points.
    raw = pd.read_csv(BASE / "data/heart.csv", na_values=["?"])
    train, test = train_test_split(raw, test_size=0.2, random_state=42, stratify=raw.target)
    _, _, _, original = heart.discretize_training_and_test(train, test)
    altered = test.copy()
    altered[heart.CONTINUOUS] = 1e9
    _, _, _, modified = heart.discretize_training_and_test(train, altered)
    assert original == modified
    print("PASS: All 14 heart variables have normalized CPDs; valid held-out posteriors; no binning leakage.")

    cv = load("07_five_fold_cv.py")
    with contextlib.redirect_stdout(io.StringIO()):
        scores, coverage = cv.main()
    assert scores.shape == (5, 4) and (coverage == 1).all()
    assert ((scores >= 0) & (scores <= 1)).all().all()
    print("PASS: Exactly five CV folds; each of 150 samples is validated once; all metrics are bounded.")
    print("All regression checks passed.")


if __name__ == "__main__":
    main()
