# Computing Lab 1 - corrected Python programs

All eight requested experiments are included, in the requested order. The code follows the supplied lab records while correcting syntax, runtime, numerical and evaluation errors. Extra experiments in the longer record are outside this package.

## Start in Google Colab

1. Open [Google Colab](https://colab.research.google.com/).
2. Choose **File > Upload notebook** and upload `Computing_Lab1.ipynb`.
3. Connect to a Python runtime. A CPU runtime is sufficient.
4. Run the notebook from the top. The setup cell installs the required libraries; the data cell restores all CSV files into `computing_lab1_workspace/data`.
5. Run an experiment's code cell. Plots, metrics and predictions are displayed or saved under `results`. The final section demonstrates optional upload, download and Google Drive access.
6. Save a copy of the notebook to Drive and download results you want to retain.

The notebook contains the complete program source and embedded datasets: uploading the ZIP separately is unnecessary. Saved notebook outputs were produced in a local Python 3.12 kernel, not a live Colab session. Re-running in Colab refreshes them.

Colab resource availability and runtime duration vary. The old hardware models, fixed quotas and guaranteed session lengths in the reference are not promises. Notebook files can be downloaded as `.ipynb`; runtime files are separate and temporary. See the [official Colab FAQ](https://research.google.com/colaboratory/faq.html).

## Run locally

Use Python 3.10 or later. Extract the ZIP, open a terminal in its `computing_lab1` folder, and run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python 01_id3.py
python 02_naive_bayes.py
python 03_document_classifier.py
python 04_heart_bayesian_network.py
python 05_em_kmeans.py
python 06_knn.py
python 07_five_fold_cv.py
python 08_google_colab.py
```

On Windows, activate using `.venv\Scripts\activate`. Each program locates its datasets relative to its own file, so it can also be launched using its full path. Do not rename or move the `data` directory independently of the scripts. Plots are saved as PNGs; a desktop plot window is not required.

For deterministic ordering of tied structure-learning operations, you can launch experiment 4 with `PYTHONHASHSEED=0 python 04_heart_bayesian_network.py` on macOS/Linux. Equivalent Bayesian-network structures may vary with library versions or tie ordering. The test split always uses `random_state=42`.

## Experiments and corrections

### 1. ID3 algorithm - `01_id3.py`

**Aim:** Build a categorical decision tree using information gain and classify a new example.

**Method:** Calculate class entropy; choose the attribute with maximum information gain; create one branch per value; recurse on the remaining attributes. Stop when all labels agree or attributes are exhausted. Return the local majority label for an unseen or missing query value.

**Corrections:** Restores the missing `Node` class, eliminates reading before writing and accidental dataset overwrites, handles pure datasets and exhausted features, and uses the same `True`/`False` wind vocabulary in training and queries. Zero-gain ties still consume an attribute, so recursion terminates while allowing interactions such as XOR to be learned. This is actual categorical, multiway ID3, implemented from scratch.

**Data:** The 14-row Play Tennis/weather example transcribed from the reference. `id` is excluded from learning.

**Observed result:** Root attribute `outlook`; the provided sunny/normal-humidity sample predicts `yes`. The training tree fits 14/14 rows. This is training fit, not a claim about unseen-data accuracy.

For multiple classes, maximum entropy is `log2(number_of_classes)`; the reference's 0-to-1 entropy range applies to binary labels only.

### 2. Naive Bayes classifier - `02_naive_bayes.py`

**Aim:** Implement Gaussian Naive Bayes from scratch and evaluate CSV datasets.

**Method:** Use a stratified 80/20 train/test split; estimate per-class means, variances and priors on training data; sum Gaussian log likelihoods and log priors; choose the largest score. Report accuracy, confusion matrix and class metrics.

**Corrections:** Calculates log densities directly instead of taking the log of an exponential that can underflow to zero. Adds a positive variance floor and fits missing-value replacements using training data only. Demonstrates both Iris and Wine because the reference asks for more than one dataset.

**CSV format:** All columns except the last are numeric features; the final column contains the class. Edit `DATA_FILES` to use your own compatible CSV. Remove identifier columns first.

**Observed accuracy:** Iris `0.9667`; Wine `0.9722`.

### 3. Naive Bayes document classifier - `03_document_classifier.py`

**Aim:** Classify SMS documents as ham or spam.

**Method:** Validate labels, remove empty/conflicting/duplicate messages, split 80/20 with stratification, learn a training-only word-count vocabulary, and train `MultinomialNB` with Laplace smoothing. Predict new documents and report accuracy, spam precision/recall/F1 and the confusion matrix.

**Corrections:** Uses 80% for training rather than the reference's unusually small 20%; accepts both `label,message` and `v1,v2`; handles missing text; prevents identical messages crossing the train/test boundary. The vocabulary is fitted only on training documents, preserving the correct approach already present in the reference. Document counts use Multinomial NB, not the Gaussian procedure mistakenly repeated in parts of the record.

**Observed result:** 5,159 unique usable documents; 4,127 train and 1,032 test. Accuracy `0.9845`, spam precision `0.9667`, recall `0.9062`, F1 `0.9355`. The complete original collection contains 5,574 records; deduplication explains the lower usable count.

### 4. Heart disease using a Bayesian network - `04_heart_bayesian_network.py`

**Aim:** Learn a discrete Bayesian network and infer the class of held-out heart-disease records.

**Method:** Split UCI Cleveland data 80/20; learn medians/modes and continuous-feature tertiles on training data; use discrete BIC hill climbing with at most two parents per node; estimate conditional probability tables with a BDeu prior; use variable elimination to calculate `P(target | evidence)`. Evaluate all 61 held-out records.

**Corrections:** Uses a compatible `DiscreteBayesianNetwork` API and a pinned `pgmpy` release; discretizes continuous features before discrete learning; excludes the target from evidence; preserves isolated nodes both in the model and inside the `pgmpy 1.0.0` parameter estimator; supplies explicit category domains; checks every CPD. The reference's query from its training data is replaced by a held-out query and test accuracy. The repeated Gaussian NB algorithm in the record is replaced by the Bayesian-network procedure above.

**Data contract:** `data/heart.csv` uses **original UCI Cleveland feature coding**. Columns are `age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal, target`. `?` denotes a missing feature. Original UCI `num=0` becomes `target=0` (absence); `num=1..4` becomes `target=1` (presence). The original target values remain in `processed.cleveland.data`. Some Kaggle variants recode chest-pain, slope and thal states or reverse a target meaning: do not substitute those files without adapting the mappings.

**Observed accuracy:** `0.8689` on 61 test records in the supplied run. Learned arrows describe a statistical factorization, not proven causal effects. This small educational model and its probability estimates are not clinically validated.

**Outputs:** `heart_network.png`, `heart_predictions.csv`.

### 5. EM and K-Means clustering - `05_em_kmeans.py`

**Aim:** Compare hard clustering with K-Means and probabilistic clustering with a Gaussian mixture fitted by Expectation-Maximization.

**Method:** Remove the species label and identifiers; standardize the four numeric Iris features; fit three clusters/components with repeated initialization; compare silhouette scores and optionally adjusted Rand indices against species. Check EM convergence and display membership probabilities.

**Corrections:** Repairs the missing `if` and malformed `else`; consistently excludes species/variety/class labels; fixes initialization settings and verifies that silhouette is defined. Both algorithms use the same standardized features. The plot shows only the first two dimensions; fitting and metrics use all four.

**Observed scores:** K-Means silhouette `0.4599`, adjusted Rand index `0.6201`; EM silhouette `0.3742`, adjusted Rand index `0.9039`. K-Means has the larger silhouette here, while EM agrees more closely with species. These metrics assess different properties. Raw cluster IDs are arbitrary and must not be treated directly as class predictions.

**Outputs:** `clustering_comparison.png`, `cluster_assignments.csv`.

### 6. K-nearest neighbors - `06_knn.py`

**Aim:** Classify Iris with KNN and list correct and incorrect predictions.

**Method:** Make a stratified 60/40 train/test split, preserving the ratio in the reference. Fit a `StandardScaler` and a three-neighbor classifier inside one pipeline. Print the original features, actual/predicted labels and accuracy for the held-out samples.

**Corrections:** Actually uses the scaler that the reference only imported; fits it on training rows; excludes identifiers; retains row alignment when comparing predictions. No test labels are used to choose `k`.

**Observed result:** 57 correct and 3 incorrect predictions out of 60; accuracy `0.9500`.

**Output:** `knn_predictions.csv`.

### 7. Five-fold cross validation - `07_five_fold_cv.py`

**Aim:** Compare accuracy, macro precision, macro recall and macro F1 across five folds.

**Method:** Shuffle with a fixed seed and use `StratifiedKFold` to preserve class balance. Train a fresh entropy decision tree on four folds and evaluate on the fifth. Repeat five times and report each metric's mean and sample standard deviation. Every sample is validated exactly once.

**Corrections:** Uses stratification for classification, handles zero-division cases and reports variability. A model is fitted separately within each fold; no full-data prefit is required. The sklearn entropy tree here uses binary CART splits and is distinct from the ID3 implementation in experiment 1.

**Observed fold accuracies:** `1.0000, 0.9667, 0.9333, 0.9667, 0.9000`. Mean accuracy `0.9533`; mean macro precision `0.9572`, recall `0.9533`, F1 `0.9531`.

**Outputs:** `five_fold_scores.csv`, `five_fold_summary.csv`.

### 8. Familiarization of Google Colab - `08_google_colab.py`

**Aim:** Practice notebook execution, Python libraries, data files, visualization and a small ML workflow in a cloud notebook.

**Activities:** Create and run Markdown/code cells; inspect the Python version; compute with NumPy; summarize a pandas DataFrame; save and reload a CSV; draw a chart; train/test an Iris classifier; save results. The notebook adds optional cells for file upload, result download, Drive mounting and accelerator inspection.

**Corrections:** Replaces the reference's theory-only exercise with executable demonstrations and removes stale guarantees about GPUs, quotas and runtime duration. CPU-only execution is sufficient. File upload, Google Drive authorization and downloads require a live Colab session; those optional steps were not exercised in the local validation.

**Observed result:** CSV round trip succeeds; Iris accuracy `0.9667`; the chart and CSV are saved. Timing and platform text vary by machine.

## Datasets, credits and official references

Only PDF records were attached; no original CSV files were supplied. The weather CSV was reconstructed from the code listing. Iris and Wine were exported from scikit-learn's bundled datasets; heart and SMS data were downloaded directly from UCI. These are suitable runnable datasets, not a claim to reproduce unseen private CSVs from the screenshots. Test results can therefore differ from the reference screenshots.

Dataset provenance, transformations, attribution and checksums are in `data/SOURCES.md` and `data/manifest.json`. The original SMS attribution/readme is retained.

- [UCI Heart Disease](https://archive.ics.uci.edu/dataset/45/heart+disease), Janosi, Steinbrunn, Pfisterer and Detrano (1988), DOI `10.24432/C52P4X`.
- [UCI SMS Spam Collection](https://archive.ics.uci.edu/dataset/228/sms+spam+collection), Almeida and Hidalgo (2011), DOI `10.24432/C5CC84`.
- [scikit-learn bundled datasets](https://scikit-learn.org/stable/datasets/toy_dataset.html).
- [scikit-learn Naive Bayes](https://scikit-learn.org/stable/modules/naive_bayes.html).
- [pgmpy 1.0.0 hill-climb source/API](https://pgmpy.org/_modules/pgmpy/estimators/HillClimbSearch.html).
- [Google Colab FAQ](https://research.google.com/colaboratory/faq.html).

## Validation

The eight scripts were executed locally with Python 3.12, scikit-learn 1.7.2, pgmpy 1.0.0 and Matplotlib 3.10.7. The notebook was also executed from a fresh Python kernel; saved outputs show that run. Full script output is in `results/01_*.txt` through `results/08_*.txt`. Some library information messages can appear on standard error without indicating a failure. Installed dependency versions are recorded in `results/environment.txt`.

`verify_algorithms.py` additionally checks ID3 stopping cases, unseen values and XOR; Gaussian NB stability on constant/extreme inputs and agreement with sklearn on the bundled numerical datasets; disjoint SMS train/test messages; preservation of all heart-network variables and normalized CPDs/posteriors; and exactly-once validation coverage across five folds.
