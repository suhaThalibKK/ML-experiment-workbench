# Computing Lab 1 - complete corrected programs

All eight programs were run locally. See README.md for aims, algorithms, corrections, dataset coding, results and Colab instructions. Keep the supplied data folder alongside the Python scripts.

```bash
python -m pip install -r requirements.txt
```


## 01 id3


```python
"""Experiment 1: categorical ID3, implemented from scratch."""
from collections import Counter
from dataclasses import dataclass, field
from math import log2
from pathlib import Path

import pandas as pd

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
DATA_FILE = BASE_DIR / "data" / "weather.csv"


@dataclass
class Node:
    prediction: str  # Majority class at this node; also the unseen-value fallback.
    attribute: str | None = None
    children: dict = field(default_factory=dict)


def entropy(labels):
    counts = Counter(labels)
    total = sum(counts.values())
    return -sum((n / total) * log2(n / total) for n in counts.values()) if total else 0.0


def information_gain(data, attribute, target):
    weighted_entropy = sum(
        len(group) / len(data) * entropy(group[target])
        for _, group in data.groupby(attribute, sort=True)
    )
    return entropy(data[target]) - weighted_entropy


def id3(data, attributes, target="play"):
    if data.empty:
        raise ValueError("ID3 needs nonempty training data.")
    # Alphabetical tie-breaking makes the result reproducible.
    counts = Counter(data[target])
    majority = sorted(counts, key=lambda label: (-counts[label], str(label)))[0]
    node = Node(prediction=majority)
    if len(counts) == 1 or not attributes:
        return node
    best = max(attributes, key=lambda name: information_gain(data, name, target))
    # Split even when gain is zero: later attributes can resolve an XOR pattern.
    node.attribute = best
    remaining = [name for name in attributes if name != best]
    for value, group in data.groupby(best, sort=True):
        node.children[value] = id3(group, remaining, target)
    return node


def classify(node, sample):
    while node.attribute is not None:
        child = node.children.get(sample.get(node.attribute))
        if child is None:
            return node.prediction
        node = child
    return node.prediction


def print_tree(node, indent=""):
    if node.attribute is None:
        print(indent + "Predict: " + str(node.prediction))
        return
    print(indent + node.attribute + " [fallback=" + str(node.prediction) + "]")
    for value, child in node.children.items():
        print(indent + "  " + str(value) + ":")
        print_tree(child, indent + "    ")


def main():
    # Read the existing file; do not overwrite it or read before creating it.
    data = pd.read_csv(DATA_FILE, dtype=str)
    target = "play"
    features = [name for name in data if name not in {target, "id"}]
    if target not in data or not features or data[features + [target]].isna().any().any():
        raise ValueError("Expected complete categorical features and a 'play' target.")
    print("Information gain:")
    for feature in features:
        print(f"  {feature}: {information_gain(data, feature, target):.4f}")
    root = id3(data, features, target)
    print("\nDecision tree:")
    print_tree(root)
    sample = {"outlook": "sunny", "temperature": "hot", "humidity": "normal", "windy": "False"}
    print("\nNew sample:", sample)
    print("Predicted label:", classify(root, sample))
    correct = sum(classify(root, row) == row[target] for row in data.to_dict("records"))
    print(f"Training fit (not a test accuracy): {correct}/{len(data)}")
    return root


if __name__ == "__main__":
    main()
```


## 02 naive bayes


```python
"""Experiment 2: numerically stable Gaussian Naive Bayes from scratch."""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
# Last column is the target; every preceding column must be a numeric feature.
DATA_FILES = [BASE_DIR / "data" / "iris.csv", BASE_DIR / "data" / "wine.csv"]


class GaussianNBFromScratch:
    def fit(self, X, y):
        X, y = np.asarray(X, dtype=float), np.asarray(y)
        if X.ndim != 2 or not len(X) or len(X) != len(y) or not np.isfinite(X).all():
            raise ValueError("Expected finite 2-D features and matching labels.")
        self.classes_ = np.unique(y)
        self.means_ = np.array([X[y == label].mean(axis=0) for label in self.classes_])
        variances = np.array([X[y == label].var(axis=0) for label in self.classes_])
        # A floor handles constant features, including an entirely constant dataset.
        epsilon = max(1e-9 * float(X.var(axis=0).max()), 1e-12)
        self.variances_ = variances + epsilon
        self.log_priors_ = np.log([np.mean(y == label) for label in self.classes_])
        return self

    def joint_log_likelihood(self, X):
        X = np.asarray(X, dtype=float)
        # Evaluate log Gaussian densities directly; never take log(exp(...)).
        return self.log_priors_ - 0.5 * np.sum(
            np.log(2 * np.pi * self.variances_)
            + (X[:, None, :] - self.means_) ** 2 / self.variances_, axis=2
        )

    def predict(self, X):
        return self.classes_[np.argmax(self.joint_log_likelihood(X), axis=1)]


def run_dataset(path):
    data = pd.read_csv(path, na_values=["?", "", "NA"])
    data = data.dropna(subset=[data.columns[-1]])
    X = data.iloc[:, :-1].apply(pd.to_numeric, errors="raise")
    y = data.iloc[:, -1]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    # Learn replacement values from training rows only.
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    X_train = imputer.fit_transform(X_train)
    X_test = imputer.transform(X_test)
    model = GaussianNBFromScratch().fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"\nDataset: {path.name} | train={len(y_train)}, test={len(y_test)}")
    print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print("Confusion matrix (class order:", list(model.classes_), ")")
    print(confusion_matrix(y_test, predictions, labels=model.classes_))
    print(classification_report(y_test, predictions, zero_division=0))
    print(pd.DataFrame({"Actual": np.asarray(y_test), "Predicted": predictions}).head().to_string(index=False))
    return model, X_test, np.asarray(y_test), predictions


def main():
    for path in DATA_FILES:
        run_dataset(path)


if __name__ == "__main__":
    main()
```


## 03 document classifier


```python
"""Experiment 3: SMS document classification with Multinomial Naive Bayes."""
from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
DATA_FILE = BASE_DIR / "data" / "spam.csv"


def main():
    try:
        data = pd.read_csv(DATA_FILE, encoding="utf-8")
    except UnicodeDecodeError:
        data = pd.read_csv(DATA_FILE, encoding="latin-1")
    # Also accept the v1/v2 column names used in the reference program.
    data = data.rename(columns={"v1": "label", "v2": "message"})[["label", "message"]]
    data = data.dropna(subset=["label", "message"]).copy()
    data["label"] = data["label"].str.strip().str.lower()
    if not data["label"].isin(["ham", "spam"]).all():
        raise ValueError("Labels must be 'ham' or 'spam'.")
    data["message"] = data["message"].astype(str).str.strip()
    data = data[data["message"].ne("")]
    # Remove identical messages before splitting; duplicates can inflate test scores.
    data["key"] = data["message"].str.lower().str.replace(r"\s+", " ", regex=True)
    conflicts = data.groupby("key")["label"].nunique()
    data = data[~data["key"].isin(conflicts[conflicts > 1].index)]
    data = data.drop_duplicates("key")
    X_train, X_test, y_train, y_test = train_test_split(
        data["message"], data["label"], test_size=0.2, random_state=42, stratify=data["label"]
    )
    # The vocabulary is learned only from training documents.
    model = make_pipeline(CountVectorizer(), MultinomialNB(alpha=1.0))
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"Unique usable documents: {len(data)} | train={len(X_train)}, test={len(X_test)}")
    print(f"Accuracy : {accuracy_score(y_test, predictions):.4f}")
    print(f"Precision: {precision_score(y_test, predictions, pos_label='spam', zero_division=0):.4f}")
    print(f"Recall   : {recall_score(y_test, predictions, pos_label='spam', zero_division=0):.4f}")
    print(f"F1-score : {f1_score(y_test, predictions, pos_label='spam', zero_division=0):.4f}")
    print("Confusion matrix: rows=actual, columns=predicted; order=[ham, spam]")
    print(confusion_matrix(y_test, predictions, labels=["ham", "spam"]))
    messages = ["Congratulations! Claim your free cash prize now", "Can we meet at the library after class?"]
    print("\nNew document predictions:")
    for message, label in zip(messages, model.predict(messages)):
        print(f"{label}: {message}")
    return model, X_train, X_test


if __name__ == "__main__":
    main()
```


## 04 heart bayesian network


```python
"""Experiment 4: learn a discrete Bayesian network on Cleveland heart data.

Educational classification experiment; these predictions are not clinical diagnoses.
Uses pgmpy 1.0.0, with training-only discretization and a held-out test set.
"""
from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from pgmpy.estimators import BayesianEstimator, HillClimbSearch
from pgmpy.inference import VariableElimination
from pgmpy.models import DiscreteBayesianNetwork
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
DATA_FILE = BASE_DIR / "data" / "heart.csv"
RESULTS_DIR = BASE_DIR / "results"
CONTINUOUS = ["age", "trestbps", "chol", "thalach", "oldpeak"]
# Original UCI Cleveland coding, NOT the recoded categories of some Kaggle files.
CATEGORIES = {
    "sex": [0, 1], "cp": [1, 2, 3, 4], "fbs": [0, 1], "restecg": [0, 1, 2],
    "exang": [0, 1], "slope": [1, 2, 3], "ca": [0, 1, 2, 3], "thal": [3, 6, 7],
}
FEATURES = CONTINUOUS + list(CATEGORIES)


def discretize_training_and_test(train, test):
    train_d, test_d = pd.DataFrame(index=train.index), pd.DataFrame(index=test.index)
    states, rules = {}, {}
    for column in FEATURES:
        if train[column].notna().sum() == 0:
            raise ValueError(f"No observed training values in {column}.")
        if column in CONTINUOUS:
            replacement = float(train[column].median())
            train_values = train[column].fillna(replacement)
            test_values = test[column].fillna(replacement)
            cuts = np.unique(np.quantile(train_values, [1 / 3, 2 / 3]))
            train_d[column] = np.searchsorted(cuts, train_values, side="right")
            test_d[column] = np.searchsorted(cuts, test_values, side="right")
            states[column] = list(range(len(cuts) + 1))
            rules[column] = {"median": replacement, "cut_points": cuts.tolist()}
        else:
            replacement = int(train[column].mode().iloc[0])
            train_d[column] = train[column].fillna(replacement).astype(int)
            test_d[column] = test[column].fillna(replacement).astype(int)
            states[column] = CATEGORIES[column]
            rules[column] = {"mode": replacement, "states": CATEGORIES[column]}
    return train_d, test_d, states, rules


def main():
    data = pd.read_csv(DATA_FILE, na_values=["?", "", "NA"])
    required = FEATURES + ["target"]
    if not set(required).issubset(data.columns):
        raise ValueError("Expected UCI Cleveland columns: " + ", ".join(required))
    data = data[required].apply(pd.to_numeric, errors="raise").dropna(subset=["target"])
    if not data["target"].isin([0, 1]).all():
        raise ValueError("target must be 0=absence, 1=presence (map original num > 0 to 1).")
    data["target"] = data["target"].astype(int)
    for column, domain in CATEGORIES.items():
        if not data[column].dropna().isin(domain).all():
            raise ValueError(f"{column} must use original Cleveland states {domain}.")
    if np.isinf(data[FEATURES].to_numpy()).any():
        raise ValueError("Features cannot contain infinite values.")
    train, test = train_test_split(data, test_size=0.2, random_state=42, stratify=data["target"])
    train_d, test_d, states, rules = discretize_training_and_test(train, test)
    train_d["target"] = train["target"]
    states["target"] = [0, 1]

    print(f"Records: {len(data)} | train={len(train)}, test={len(test)}")
    print("Continuous features are binned using training-set tertiles.")
    structure = HillClimbSearch(train_d, state_names=states).estimate(
        scoring_method="bic-d", max_indegree=2, max_iter=1000, show_progress=False
    )
    model = DiscreteBayesianNetwork()
    # An edge-only constructor loses isolated variables, potentially the target.
    model.add_nodes_from(train_d.columns)
    model.add_edges_from(structure.edges())
    estimator = BayesianEstimator(model, train_d, state_names=states)
    # pgmpy 1.0.0 also rebuilds the graph inside BayesianEstimator from edges.
    # Restore isolated nodes there so they receive their own prior CPDs.
    estimator.model.add_nodes_from(model.nodes())
    model.add_cpds(*estimator.get_parameters(
        prior_type="BDeu", equivalent_sample_size=5, n_jobs=1
    ))
    if not model.check_model():
        raise RuntimeError("Invalid Bayesian network.")
    print("Learned edges:", sorted(model.edges()))
    print("\nTraining preprocessing rules:")
    for name in CONTINUOUS:
        print(name, rules[name])

    inference = VariableElimination(model)
    predictions, probabilities = [], []
    for _, row in test_d.iterrows():
        evidence = {column: int(row[column]) for column in FEATURES}
        posterior = inference.query(["target"], evidence=evidence, show_progress=False)
        ordered_states = posterior.state_names["target"]
        predictions.append(ordered_states[int(np.argmax(posterior.values))])
        probabilities.append(float(posterior.values[ordered_states.index(1)]))
    print(f"\nHeld-out accuracy: {accuracy_score(test['target'], predictions):.4f}")
    print("Confusion matrix: rows=actual, columns=predicted; order=[0, 1]")
    print(confusion_matrix(test["target"], predictions, labels=[0, 1]))
    print(classification_report(test["target"], predictions, labels=[0, 1], zero_division=0))
    print("First held-out example (raw features):", test.iloc[0][FEATURES].to_dict())
    print("Evidence after preprocessing:", test_d.iloc[0].to_dict())
    print(f"P(target=1 | evidence) = {probabilities[0]:.4f}; prediction = {predictions[0]}")
    print("Educational prediction only; probabilities are not clinically validated.")

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"row": test.index, "actual": test["target"].to_numpy(),
                  "predicted": predictions, "p_presence": probabilities}).to_csv(
        RESULTS_DIR / "heart_predictions.csv", index=False
    )
    fig, ax = plt.subplots(figsize=(11, 7))
    graph = nx.DiGraph(model)
    levels = [sorted(nodes) for nodes in nx.topological_generations(graph)]
    positions = {node: (i - (len(nodes) - 1) / 2, -depth)
                 for depth, nodes in enumerate(levels) for i, node in enumerate(nodes)}
    nx.draw_networkx(graph, pos=positions, ax=ax,
                     node_color="#c5e5f5", node_size=1700, font_size=9, arrowsize=18)
    ax.set_title("Learned Bayesian network - UCI Cleveland (training data)")
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "heart_network.png", dpi=160)
    plt.close(fig)
    return model, test_d, states, probabilities


if __name__ == "__main__":
    main()
```


## 05 em kmeans


```python
"""Experiment 5: compare K-Means and EM-fitted Gaussian mixture clustering."""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
DATA_FILE = BASE_DIR / "data" / "iris.csv"
RESULTS_DIR = BASE_DIR / "results"
N_CLUSTERS = 3


def main():
    data = pd.read_csv(DATA_FILE)
    # Species is used only for the external evaluation, never for fitting.
    target = next((c for c in data if c.lower() in {"species", "variety", "class"}), None)
    labels = data[target] if target else None
    features = data.drop(columns=[c for c in data if c == target or c.lower() == "id"])
    X = features.apply(pd.to_numeric, errors="raise").to_numpy()
    if X.shape[1] < 2 or not np.isfinite(X).all():
        raise ValueError("Expected at least two complete numeric feature columns.")
    X_scaled = StandardScaler().fit_transform(X)
    kmeans = KMeans(n_clusters=N_CLUSTERS, n_init=10, random_state=42)
    # GaussianMixture learns its parameters using Expectation-Maximization.
    gmm = GaussianMixture(n_components=N_CLUSTERS, covariance_type="full",
                          n_init=10, max_iter=500, reg_covar=1e-6, random_state=42)
    km_labels = kmeans.fit_predict(X_scaled)
    em_labels = gmm.fit_predict(X_scaled)
    if not gmm.converged_:
        raise RuntimeError("EM did not converge; increase max_iter or inspect the data.")
    scores = {}
    for name, clusters in [("K-Means", km_labels), ("EM (GMM)", em_labels)]:
        count = len(np.unique(clusters))
        if not 1 < count < len(X_scaled):
            raise ValueError("Silhouette requires 2 to n_samples-1 populated clusters.")
        scores[name] = silhouette_score(X_scaled, clusters)
        print(f"{name}: silhouette={scores[name]:.4f}; cluster counts={np.bincount(clusters)}")
        if labels is not None:
            print(f"  Adjusted Rand index vs species: {adjusted_rand_score(labels, clusters):.4f}")
    print(f"EM converged: {gmm.converged_}; iterations: {gmm.n_iter_}")
    print("Larger silhouette on this dataset:", max(scores, key=scores.get))
    print("This comparison does not establish that one method is always better.")
    print("First sample's EM membership probabilities:", gmm.predict_proba(X_scaled[:1])[0].round(4))

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), sharex=True, sharey=True)
    for ax, name, clusters, centers in zip(
        axes, ["K-Means", "EM (Gaussian mixture)"], [km_labels, em_labels],
        [kmeans.cluster_centers_, gmm.means_]
    ):
        ax.scatter(X_scaled[:, 0], X_scaled[:, 1], c=clusters, cmap="viridis", s=30)
        ax.scatter(centers[:, 0], centers[:, 1], color="#d43f3a", marker="X", s=150, label="Centers")
        ax.set_title(name)
        ax.set_xlabel(features.columns[0] + " (standardized)")
        ax.legend()
    axes[0].set_ylabel(features.columns[1] + " (standardized)")
    fig.suptitle("Iris: first two features shown; clustering uses all four")
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "clustering_comparison.png", dpi=160)
    plt.close(fig)
    pd.DataFrame({"kmeans": km_labels, "em_gmm": em_labels}).to_csv(
        RESULTS_DIR / "cluster_assignments.csv", index=False
    )
    return kmeans, gmm, X_scaled


if __name__ == "__main__":
    main()
```


## 06 knn


```python
"""Experiment 6: scaled KNN with correct and incorrect predictions."""
from pathlib import Path

import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
DATA_FILE = BASE_DIR / "data" / "iris.csv"
K = 3


def main():
    data = pd.read_csv(DATA_FILE)
    target = next((c for c in data if c.lower() in {"species", "variety", "class"}), data.columns[-1])
    X = data.drop(columns=[c for c in data if c == target or c.lower() == "id"])
    X = X.apply(pd.to_numeric, errors="raise")
    y = data[target]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.4, random_state=42, stratify=y
    )
    # Scaling is fitted to the training data and reused unchanged on test data.
    model = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=K))
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    comparison = X_test.copy()
    comparison["actual"] = y_test
    comparison["predicted"] = predictions
    comparison["correct"] = comparison["actual"] == comparison["predicted"]
    print(f"k={K} | train={len(X_train)}, test={len(X_test)}")
    for correct, title in [(True, "Correct predictions"), (False, "Incorrect predictions")]:
        subset = comparison[comparison["correct"] == correct]
        print(f"\n{title}: {len(subset)}")
        print(subset.to_string() if len(subset) else "None")
    print(f"\nAccuracy: {accuracy_score(y_test, predictions):.4f}")
    print("Confusion matrix, class order:", list(model.classes_))
    print(confusion_matrix(y_test, predictions, labels=model.classes_))
    out = BASE_DIR / "results"
    out.mkdir(parents=True, exist_ok=True)
    comparison.to_csv(out / "knn_predictions.csv", index_label="row")
    return model, comparison


if __name__ == "__main__":
    main()
```


## 07 five fold cv


```python
"""Experiment 7: five stratified folds, with a fresh decision tree per fold."""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.tree import DecisionTreeClassifier

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent
DATA_FILE = BASE_DIR / "data" / "iris.csv"


def main():
    data = pd.read_csv(DATA_FILE)
    target = next((c for c in data if c.lower() in {"species", "variety", "class"}), data.columns[-1])
    X = data.drop(columns=[c for c in data if c == target or c.lower() == "id"])
    X = X.apply(pd.to_numeric, errors="raise")
    y = data[target]
    if y.value_counts().min() < 5:
        raise ValueError("Each class needs at least five samples for five stratified folds.")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    rows = []
    validation_count = np.zeros(len(data), dtype=int)
    for fold, (train_indices, test_indices) in enumerate(cv.split(X, y), start=1):
        # sklearn's entropy decision tree uses binary CART splits; it is not ID3.
        model = DecisionTreeClassifier(criterion="entropy", random_state=42)
        model.fit(X.iloc[train_indices], y.iloc[train_indices])
        predictions = model.predict(X.iloc[test_indices])
        actual = y.iloc[test_indices]
        validation_count[test_indices] += 1
        rows.append({
            "fold": fold, "accuracy": accuracy_score(actual, predictions),
            "precision_macro": precision_score(actual, predictions, average="macro", zero_division=0),
            "recall_macro": recall_score(actual, predictions, average="macro", zero_division=0),
            "f1_macro": f1_score(actual, predictions, average="macro", zero_division=0),
        })
    assert np.all(validation_count == 1), "Each row must be validated exactly once."
    scores = pd.DataFrame(rows).set_index("fold")
    print("Per-fold metrics (macro averaging gives each class equal weight):")
    print(scores.to_string(float_format=lambda value: f"{value:.4f}"))
    summary = pd.DataFrame({"mean": scores.mean(), "sample_std": scores.std(ddof=1)})
    print("\nSummary across five folds:")
    print(summary.to_string(float_format=lambda value: f"{value:.4f}"))
    out = BASE_DIR / "results"
    out.mkdir(parents=True, exist_ok=True)
    scores.to_csv(out / "five_fold_scores.csv")
    summary.to_csv(out / "five_fold_summary.csv")
    return scores, validation_count


if __name__ == "__main__":
    main()
```


## 08 google colab


```python
"""Experiment 8: Python, NumPy, pandas, plots, files and ML in Google Colab.

This script also runs locally. Colab-only upload/Drive/download examples are in
the notebook's final section and are optional interactive steps.
"""
import platform
from pathlib import Path
from time import perf_counter

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

BASE_DIR = Path(globals().get("__file__", "Computing_Lab1.ipynb")).resolve().parent


def main():
    print("Python:", platform.python_version())
    print("Operating system:", platform.system())
    print("Hello, Google Colab!")
    matrix = np.array([[1, 2], [3, 4]])
    print("\nNumPy matrix:\n", matrix)
    print("Matrix product A @ A:\n", matrix @ matrix)
    frame = pd.DataFrame({"student": ["A", "B", "C"], "marks": [78, 85, 92]})
    print("\npandas DataFrame:\n", frame.to_string(index=False))
    print("Mean mark:", frame["marks"].mean())
    out = BASE_DIR / "results"
    out.mkdir(parents=True, exist_ok=True)
    frame.to_csv(out / "colab_demo.csv", index=False)
    reloaded = pd.read_csv(out / "colab_demo.csv")
    print("CSV saved and read back:", reloaded.equals(frame))
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(frame["student"], frame["marks"], color="#277da1")
    ax.set(xlabel="Student", ylabel="Marks", title="Google Colab: plotting example", ylim=(0, 100))
    fig.tight_layout()
    fig.savefig(out / "colab_demo.png", dpi=160)
    plt.close(fig)

    dataset = load_iris()
    X_train, X_test, y_train, y_test = train_test_split(
        dataset.data, dataset.target, test_size=0.2, random_state=42, stratify=dataset.target
    )
    start = perf_counter()
    model = GaussianNB().fit(X_train, y_train)
    print(f"\nIris test accuracy: {accuracy_score(y_test, model.predict(X_test)):.4f}")
    print(f"Fit and prediction time: {perf_counter() - start:.4f} seconds (machine-dependent)")
    print("Results saved in:", out)
    print("These experiments run on a CPU; a GPU is not required.")


if __name__ == "__main__":
    main()
```
